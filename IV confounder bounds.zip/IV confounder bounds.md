```R
library(knitr)
knitr::opts_chunk$set(echo = TRUE)
library(stats)
library(ggplot2)
library(dplyr)
library(tidyr)
#library(EnvStats)
library(haven)
library(lme4)
library(lmerTest)
#library(sjPlot)
#library(sjstats)
#library(piecewiseSEM)
library(MuMIn)
library(sensemakr)
library(rpart)
library(rpart.plot)
library(tipr)
library(insight)
library(ggformula)
library(dplyr)
library(sandwich)
library(lmtest)
library(clubSandwich)
library(AER)
library("fixest")

```

    
    Attaching package: 'dplyr'
    
    
    The following objects are masked from 'package:stats':
    
        filter, lag
    
    
    The following objects are masked from 'package:base':
    
        intersect, setdiff, setequal, union
    
    
    Loading required package: Matrix
    
    
    Attaching package: 'Matrix'
    
    
    The following objects are masked from 'package:tidyr':
    
        expand, pack, unpack
    
    
    
    Attaching package: 'lmerTest'
    
    
    The following object is masked from 'package:lme4':
    
        lmer
    
    
    The following object is masked from 'package:stats':
    
        step
    
    
    See details in:
    
    Carlos Cinelli and Chad Hazlett (2020). Making Sense of Sensitivity: Extending Omitted Variable Bias. Journal of the Royal Statistical Society, Series B (Statistical Methodology).
    
    
    Attaching package: 'insight'
    
    
    The following object is masked from 'package:MuMIn':
    
        get_call
    
    
    Loading required package: scales
    
    Loading required package: ggridges
    
    
    New to ggformula?  Try the tutorials: 
    	learnr::run_tutorial("introduction", package = "ggformula")
    	learnr::run_tutorial("refining", package = "ggformula")
    
    Loading required package: zoo
    
    
    Attaching package: 'zoo'
    
    
    The following objects are masked from 'package:base':
    
        as.Date, as.Date.numeric
    
    
    Registered S3 method overwritten by 'clubSandwich':
      method    from    
      bread.mlm sandwich
    
    Loading required package: car
    
    Loading required package: carData
    
    
    Attaching package: 'car'
    
    
    The following object is masked from 'package:dplyr':
    
        recode
    
    
    Loading required package: survival
    
    
    Attaching package: 'fixest'
    
    
    The following object is masked from 'package:scales':
    
        pvalue
    
    
    The following object is masked from 'package:MuMIn':
    
        coefplot
    
    



```R
# function to estimate bounds

estimate_bounds <- function(df_results, treatment_var, outcome_var, controls, bin_size=NA, grouping=NA){
    # if we are doing bins (i.e. bin size is given) based on R2 of the first stage 
    # -> chop dataset according to bins
    if (!is.na(bin_size)){
        # create approximately equal sized bins
        num_bins=round(dim(df_results)[1]/bin_size)
        bin_cutoffs <- quantile(df_results$predict_ff, probs = seq(0, 1, length.out = num_bins + 1))
        # create bins based on the cutoffs
        df_results$grouping <- tryCatch({cut(df_results$predict_ff, breaks = bin_cutoffs, include.lowest = TRUE)},
        error = function(e) {
        message("pick bigger bin size - breaks are not unique")
        return(NA)
      })
        # save thresholds for bins
        df_results$intervals <- lapply(df_results$grouping,as.character)
        df_results <- df_results %>% separate(intervals, into=c('threshold_lower','threshold_upper'),sep = ",")
        df_results <- df_results %>% mutate(threshold_lower = as.numeric(gsub("[^0-9.]", "",threshold_lower)),
                          threshold_upper = as.numeric(gsub("[^0-9.]", "",threshold_upper)))
        df_results$grouping <-lapply(df_results$grouping,as.character)
        
        # calculate squared residuals per bin and total sum of squares
        df_stats <- df_results  %>%
        group_by(grouping) %>% 
        mutate(mean_true=mean(true)) %>% ungroup() %>% mutate(SSR_judge=residuals_judge^2,
                                           SST=(true-mean_true)^2,
                                           SSR_ff =residuals_ff^2)
        # calculate statistics for each bin
        df_grouped <- df_stats %>% group_by(grouping,threshold_lower,threshold_upper) %>% summarise(R2_judge = 1- sum(SSR_judge)/sum(SST),
                                                                  R2_ff = 1-sum(SSR_ff)/sum(SST),
                                                                 n=n())
        
    # else chop dataset up according to provided categorical variable
    } else { 
        df_results$grouping <- grouping
        # calculate squared residuals per group
        df_stats <- df_results  %>%
        group_by(grouping) %>% 
        mutate(mean_true=mean(true)) %>% ungroup() %>% mutate(SSR_judge=residuals_judge^2,
                                           SST=(true-mean_true)^2,
                                           SSR_ff =residuals_ff^2)
        
        df_grouped <- df_stats %>% group_by(grouping) %>% summarise(R2_judge = 1- sum(SSR_judge)/sum(SST),
                                                                  R2_ff = 1-sum(SSR_ff)/sum(SST),
                                                                 n=n())      
    }
    # calculate the marginal R2 gaiined from moving from a first stage with only FF to a first stage with FF + judge random effects
    df_grouped <- df_grouped %>% mutate(marg_R2 = R2_judge-R2_ff)
    df_bins <- data.frame()

    # run regressions for subgroups
    for (s in unique(df_grouped$grouping)){
        df_sub <- df_results %>% filter(grouping==s)
        bin_size <- dim(df_sub)[1]
        #print(bin_size)
    # run regression
    formula.ydx <- as.formula(paste0(outcome_var,' ~' , treatment_var, '+ ', paste(controls,collapse='+')))
    next_iteration <- FALSE
    model.ydx <- tryCatch({ lm(
      formula.ydx,
      data = df_sub
      ) }, error = function(e) {
    # Set the flag to TRUE if an error occurs
    next_iteration <<- TRUE
    message("Error encountered-regression singular")
  })
    if (next_iteration) {
    next
      }

    # get coefficient of outcome regressed on treatment conditional on covariates
    effect_observed = tryCatch({ summary(model.ydx)$coefficients[treatment_var,'Estimate']}, error = function(e) {
    # Set the flag to TRUE if an error occurs
    next_iteration <<- TRUE
    message("Error encountered-regression singular")
  })
        
        if (next_iteration) {
    next
      }
    # get std of outcome regressed on treatment conditional on covariates
    se =summary(model.ydx)$coefficients[treatment_var,'Std. Error']
        
    # get R2 of treatment with confounder conditional on covariates
    # would be 1- R2 of all covariates and judge effects?!
    obs_confounder_exposure_r2 = 1-(df_grouped %>% filter(grouping==s))['R2_judge'][[1]]
        if( length(obs_confounder_exposure_r2)==0){
        print('neg.  or invalid R2')
        next
    }
    if(obs_confounder_exposure_r2>1 | is.na(obs_confounder_exposure_r2)){
        print('neg.  or invalid R2')
        next
    }
        
    
    dgf <- summary(model.ydx)$df[2]
    
    # apply Cinelli & Hazlett Formula for bounding
    stats <-  tryCatch({tip_coef_with_r2(
    effect_observed,
    se,
    dgf,
    confounder_exposure_r2 = obs_confounder_exposure_r2)},  error = function(e) {
        message("cannot be explained away")
        return(data.frame())
      })
    stats <- cbind(stats, group=s, size=bin_size)
    df_bins <- rbind(df_bins,stats)
     
   }

    # calculate bounds
    #df_bins <- df_bins %>% mutate(diff = abs(lb_adjusted-ub_adjusted)) %>% filter(diff==min(diff))
    return(df_bins)
  
}
```

# EXAMINER AND JUDGE DESIGNS IN ECONOMICS: A PRACTITIONER'S GUIDE
Link to paper: https://www.nber.org/system/files/working_papers/w32348/w32348.pdf
Link to data & code: https://www.dropbox.com/scl/fo/fq2ldbu18yriqbq28kv2o/AAyFiG0RwxQxtCYwk5-DVKw?rlkey=lm4q6intf0n413pvuy82p6rc2&e=1&st=yyfp90hy&dl=0
df <- read_dta('clean_Miami_data.dta')
## 1. Sanity Check - Reproduce Table: Second Stage - OLS


```R
df <- read_dta('clean_Miami_data.dta')
head(df)
```


<table class="dataframe">
<caption>A tibble: 6 × 1115</caption>
<thead>
	<tr><th scope=col>casenumber</th><th scope=col>n_counts</th><th scope=col>n_acrime_f1</th><th scope=col>n_acrime_f2</th><th scope=col>n_acrime_f3</th><th scope=col>n_acrime_m1</th><th scope=col>n_acrime_m2</th><th scope=col>n_dcrime_f1</th><th scope=col>n_dcrime_f2</th><th scope=col>n_dcrime_f3</th><th scope=col>⋯</th><th scope=col>fe_month_x__46</th><th scope=col>fe_month_x__47</th><th scope=col>fe_month_x__48</th><th scope=col>firstname</th><th scope=col>lastname</th><th scope=col>lastfour</th><th scope=col>firstthree</th><th scope=col>missing_gender</th><th scope=col>male</th><th scope=col>id</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>⋯</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>B08054872</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>0</td><td>0</td><td>0</td><td>XAVIER </td><td>HOLMES  </td><td>HOLM</td><td>XAV</td><td>0</td><td>1</td><td>1</td></tr>
	<tr><td>B10039438</td><td>3</td><td>0</td><td>0</td><td>0</td><td>3</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>0</td><td>0</td><td>0</td><td>ANTHONY</td><td>MENENDEZ</td><td>MENE</td><td>ANT</td><td>0</td><td>1</td><td>2</td></tr>
	<tr><td>M07049470</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>0</td><td>0</td><td>0</td><td>LINTON </td><td>SEYMOUR </td><td>SEYM</td><td>LIN</td><td>0</td><td>1</td><td>3</td></tr>
	<tr><td>F06017596</td><td>1</td><td>0</td><td>0</td><td>1</td><td>0</td><td>0</td><td>1</td><td>0</td><td>0</td><td>⋯</td><td>0</td><td>0</td><td>0</td><td>WILLIE </td><td>SHARPE  </td><td>SHAR</td><td>WIL</td><td>0</td><td>1</td><td>4</td></tr>
	<tr><td>B06043832</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>0</td><td>0</td><td>0</td><td>BURTON </td><td>ANDERSON</td><td>ANDE</td><td>BUR</td><td>0</td><td>1</td><td>5</td></tr>
	<tr><td>M09048621</td><td>1</td><td>0</td><td>0</td><td>0</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>⋯</td><td>0</td><td>0</td><td>0</td><td>MARY   </td><td>BRADSHAW</td><td>BRAD</td><td>MAR</td><td>0</td><td>0</td><td>6</td></tr>
</tbody>
</table>




```R
# Assuming the data frame is named `data`
# Define the variables as in Stata
x_timeplace <- grep("^fe_", names(df), value = TRUE) # Replace with actual variable names

# Create the formula
formula <- as.formula(paste("any_guilty ~ bail_met +", paste(x_timeplace, collapse = " + ")))

# Fit the linear model
model_ff <- lm(formula, data = df)
```


```R
# Compute clustered robust standard errors
cluster_var <- df$shift
vcov_cluster <- vcovCR(model_ff, cluster = cluster_var, type = "CR2")

# Summary of the model with clustered robust standard errors
summary_cluster <- coeftest(model_ff, vcov_cluster)
print(summary_cluster)
```

    
    t test of coefficients:
    
                      Estimate  Std. Error  t value  Pr(>|t|)    
    (Intercept)     0.56712072  0.01886904  30.0556 < 2.2e-16 ***
    bail_met       -0.23265719  0.00647616 -35.9252 < 2.2e-16 ***
    fe_year_x_d_1   0.14341238  0.02718607   5.2752 1.329e-07 ***
    fe_year_x_d_2   0.21809183  0.02945331   7.4047 1.326e-13 ***
    fe_year_x_d_3   0.14588579  0.02730103   5.3436 9.133e-08 ***
    fe_year_x_d_4   0.21318461  0.02629479   8.1075 5.229e-16 ***
    fe_year_x_d_5   0.11358414  0.02849514   3.9861 6.722e-05 ***
    fe_year_x_d_6   0.15625051  0.02654496   5.8863 3.964e-09 ***
    fe_year_x_d_7   0.02393624  0.02826863   0.8467 0.3971411    
    fe_year_x_d_8   0.05376701  0.02694555   1.9954 0.0460027 *  
    fe_year_x_d_9  -0.02649263  0.02816791  -0.9405 0.3469507    
    fe_year_x_d_10  0.02724427  0.02758339   0.9877 0.3232994    
    fe_year_x_d_11 -0.08511900  0.02856443  -2.9799 0.0028842 ** 
    fe_year_x_d_12 -0.04835945  0.02955888  -1.6360 0.1018350    
    fe_year_x_d_13 -0.10542682  0.02636313  -3.9990 6.365e-05 ***
    fe_year_x_d_14 -0.03851003  0.02715642  -1.4181 0.1561702    
    fe_year_x_d_15 -0.12255259  0.02642823  -4.6372 3.537e-06 ***
    fe_year_x_d_16 -0.06807930  0.02730049  -2.4937 0.0126435 *  
    fe_year_x_d_17 -0.17396114  0.02667354  -6.5219 6.979e-11 ***
    fe_year_x_d_18 -0.14493759  0.02722478  -5.3237 1.019e-07 ***
    fe_year_x_d_19  0.22048738  0.02478421   8.8963 < 2.2e-16 ***
    fe_year_x_d_20  0.22913517  0.02005865  11.4233 < 2.2e-16 ***
    fe_year_x_d_21  0.21461170  0.02353644   9.1183 < 2.2e-16 ***
    fe_year_x_d_22  0.22262305  0.01856038  11.9945 < 2.2e-16 ***
    fe_year_x_d_23  0.19747275  0.02452958   8.0504 8.348e-16 ***
    fe_year_x_d_24  0.24212662  0.01699095  14.2503 < 2.2e-16 ***
    fe_year_x_d_25  0.16181637  0.02515552   6.4326 1.260e-10 ***
    fe_year_x_d_26  0.19174846  0.01801221  10.6455 < 2.2e-16 ***
    fe_year_x_d_27  0.08754436  0.02557884   3.4225 0.0006207 ***
    fe_year_x_d_28  0.05999153  0.01917259   3.1290 0.0017544 ** 
    fe_year_x_d_29  0.03811486  0.02557955   1.4901 0.1362139    
    fe_year_x_d_30  0.06692430  0.01939574   3.4505 0.0005599 ***
    fe_year_x_d_31  0.04218768  0.02550458   1.6541 0.0981062 .  
    fe_year_x_d_32  0.04987510  0.02031884   2.4546 0.0141050 *  
    fe_year_x_d_33  0.00553538  0.02460981   0.2249 0.8220376    
    fe_year_x_d_34  0.02514955  0.01873914   1.3421 0.1795712    
    fe_year_x_d_35 -0.02988746  0.02538571  -1.1773 0.2390651    
    fe_month_x__1   0.04806074  0.02282233   2.1059 0.0352187 *  
    fe_month_x__2   0.07656774  0.02194351   3.4893 0.0004845 ***
    fe_month_x__3   0.05149661  0.02032491   2.5337 0.0112891 *  
    fe_month_x__4   0.07707420  0.02173151   3.5467 0.0003903 ***
    fe_month_x__5   0.03454139  0.02151422   1.6055 0.1083840    
    fe_month_x__6   0.04931207  0.02121556   2.3243 0.0201096 *  
    fe_month_x__7   0.04331767  0.02030830   2.1330 0.0329270 *  
    fe_month_x__8   0.03032598  0.02218130   1.3672 0.1715700    
    fe_month_x__9   0.03040407  0.02279892   1.3336 0.1823464    
    fe_month_x__10  0.05398738  0.02248407   2.4011 0.0163460 *  
    fe_month_x__11  0.06464953  0.02369210   2.7287 0.0063589 ** 
    fe_month_x__12  0.01351715  0.02107583   0.6414 0.5212916    
    fe_month_x__13  0.04332640  0.02243816   1.9309 0.0534954 .  
    fe_month_x__14  0.03356162  0.02073760   1.6184 0.1055809    
    fe_month_x__15  0.04284865  0.02253174   1.9017 0.0572132 .  
    fe_month_x__16  0.00595378  0.02124509   0.2802 0.7792922    
    fe_month_x__17  0.04573695  0.02179042   2.0989 0.0358241 *  
    fe_month_x__18  0.05204938  0.02193999   2.3724 0.0176773 *  
    fe_month_x__19  0.02322352  0.02045342   1.1354 0.2561963    
    fe_month_x__20  0.02662514  0.02078082   1.2812 0.2001140    
    fe_month_x__21  0.02354792  0.01981331   1.1885 0.2346434    
    fe_month_x__22  0.00217404  0.02007762   0.1083 0.9137724    
    fe_month_x__25  0.05400758  0.01600759   3.3739 0.0007415 ***
    fe_month_x__26 -0.00226948  0.01878451  -0.1208 0.9038365    
    fe_month_x__27  0.02225310  0.02139937   1.0399 0.2983913    
    fe_month_x__28  0.03307031  0.02042131   1.6194 0.1053641    
    fe_month_x__29  0.02063358  0.01727992   1.1941 0.2324502    
    fe_month_x__30 -0.01315387  0.01828203  -0.7195 0.4718365    
    fe_month_x__31  0.02304771  0.01638850   1.4063 0.1596280    
    fe_month_x__32  0.01361726  0.01939908   0.7020 0.4827098    
    fe_month_x__33  0.02664192  0.01844599   1.4443 0.1486523    
    fe_month_x__34  0.00715039  0.02105231   0.3396 0.7341219    
    fe_month_x__35 -0.00994106  0.01802045  -0.5517 0.5811868    
    fe_month_x__36 -0.01220805  0.01892286  -0.6451 0.5188326    
    fe_month_x__37 -0.00538997  0.01774765  -0.3037 0.7613569    
    fe_month_x__38 -0.03680565  0.01898330  -1.9388 0.0525234 .  
    fe_month_x__39 -0.00034343  0.02095955  -0.0164 0.9869270    
    fe_month_x__40 -0.01094770  0.01944308  -0.5631 0.5733925    
    fe_month_x__41  0.03179642  0.01797525   1.7689 0.0769138 .  
    fe_month_x__42 -0.00537831  0.02113166  -0.2545 0.7990989    
    fe_month_x__43  0.01910744  0.01728716   1.1053 0.2690340    
    fe_month_x__44  0.00242465  0.02042927   0.1187 0.9055251    
    fe_month_x__45  0.00978816  0.01704706   0.5742 0.5658441    
    fe_month_x__46  0.01122689  0.02118184   0.5300 0.5960962    
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    


## 2. Estimate Confounder Bounds based on First Stage R2

### Estimate first stage with only time fixed effects


```R
# fit model only with non-judge related fixed effects
ff_formula <- as.formula(paste0('bail_met ~', paste(x_timeplace, collapse = " + ")))
fit = feols(
  ff_formula,
  data = df
)
summary(fit)
```

    The variables 'fe_year_x_d_36', 'fe_month_x__23', 'fe_month_x__24', 'fe_month_x__47' and 'fe_month_x__48' have been removed because of collinearity (see $collin.var).
    



    OLS estimation, Dep. Var.: bail_met
    Observations: 94,355
    Standard-errors: IID 
                    Estimate Std. Error    t value   Pr(>|t|)    
    (Intercept)     0.556292   0.015373  36.185622  < 2.2e-16 ***
    fe_year_x_d_1  -0.269591   0.020199 -13.346949  < 2.2e-16 ***
    fe_year_x_d_2  -0.202262   0.020316  -9.955797  < 2.2e-16 ***
    fe_year_x_d_3  -0.244760   0.020220 -12.104917  < 2.2e-16 ***
    fe_year_x_d_4  -0.209369   0.020322 -10.302558  < 2.2e-16 ***
    fe_year_x_d_5  -0.224909   0.020165 -11.153368  < 2.2e-16 ***
    fe_year_x_d_6  -0.196476   0.020170  -9.741254  < 2.2e-16 ***
    fe_year_x_d_7  -0.250551   0.020410 -12.276069  < 2.2e-16 ***
    fe_year_x_d_8  -0.211920   0.020131 -10.527241  < 2.2e-16 ***
    fe_year_x_d_9  -0.266853   0.020668 -12.911260  < 2.2e-16 ***
    fe_year_x_d_10 -0.184916   0.020354  -9.085052  < 2.2e-16 ***
    fe_year_x_d_11 -0.241430   0.021156 -11.412097  < 2.2e-16 ***
    fe_year_x_d_12 -0.173304   0.020952  -8.271578  < 2.2e-16 ***
    fe_year_x_d_13 -0.204868   0.020645  -9.923488  < 2.2e-16 ***
    fe_year_x_d_14 -0.124557   0.020467  -6.085695 1.1643e-09 ***
    fe_year_x_d_15 -0.163863   0.020453  -8.011515 1.1459e-15 ***
    fe_year_x_d_16 -0.118316   0.020685  -5.719957 1.0687e-08 ***
    fe_year_x_d_17 -0.194765   0.020868  -9.333206  < 2.2e-16 ***
    fe_year_x_d_18 -0.155304   0.020817  -7.460276 8.7079e-14 ***
    fe_year_x_d_19 -0.332813   0.020715 -16.066566  < 2.2e-16 ***
    fe_year_x_d_20 -0.353281   0.015311 -23.074301  < 2.2e-16 ***
    fe_year_x_d_21 -0.299206   0.020044 -14.927604  < 2.2e-16 ***
    fe_year_x_d_22 -0.299010   0.014529 -20.580813  < 2.2e-16 ***
    fe_year_x_d_23 -0.254849   0.019952 -12.773345  < 2.2e-16 ***
    fe_year_x_d_24 -0.282370   0.014120 -19.997217  < 2.2e-16 ***
    fe_year_x_d_25 -0.254220   0.020092 -12.653037  < 2.2e-16 ***
    fe_year_x_d_26 -0.263855   0.013797 -19.124446  < 2.2e-16 ***
    fe_year_x_d_27 -0.212696   0.020319 -10.468047  < 2.2e-16 ***
    fe_year_x_d_28 -0.218102   0.014020 -15.556119  < 2.2e-16 ***
    fe_year_x_d_29 -0.172259   0.020939  -8.226595  < 2.2e-16 ***
    fe_year_x_d_30 -0.180269   0.014904 -12.095740  < 2.2e-16 ***
    fe_year_x_d_31 -0.184940   0.020252  -9.131841  < 2.2e-16 ***
    fe_year_x_d_32 -0.228146   0.014337 -15.912933  < 2.2e-16 ***
    fe_year_x_d_33 -0.150611   0.020173  -7.466154 8.3280e-14 ***
    fe_year_x_d_34 -0.150096   0.014438 -10.396013  < 2.2e-16 ***
    fe_year_x_d_35  0.039171   0.020534   1.907637 5.6441e-02 .  
    fe_month_x__1   0.007916   0.014928   0.530258 5.9593e-01    
    fe_month_x__2  -0.003600   0.014609  -0.246415 8.0536e-01    
    fe_month_x__3   0.014921   0.014883   1.002506 3.1610e-01    
    fe_month_x__4   0.014609   0.015145   0.964618 3.3474e-01    
    fe_month_x__5   0.039791   0.014416   2.760137 5.7788e-03 ** 
    fe_month_x__6   0.004521   0.014538   0.310970 7.5582e-01    
    fe_month_x__7   0.019682   0.014710   1.338009 1.8090e-01    
    fe_month_x__8  -0.048042   0.014680  -3.272661 1.0658e-03 ** 
    fe_month_x__9   0.008973   0.014731   0.609118 5.4245e-01    
    fe_month_x__10 -0.016213   0.014489  -1.118926 2.6317e-01    
    fe_month_x__11  0.005338   0.014621   0.365092 7.1504e-01    
    fe_month_x__12 -0.032914   0.014884  -2.211328 2.7016e-02 *  
    fe_month_x__13  0.002597   0.014599   0.177861 8.5883e-01    
    fe_month_x__14 -0.014902   0.014549  -1.024211 3.0574e-01    
    fe_month_x__15  0.005222   0.014614   0.357297 7.2087e-01    
    fe_month_x__16 -0.026129   0.014643  -1.784378 7.4366e-02 .  
    fe_month_x__17  0.006144   0.014600   0.420845 6.7387e-01    
    fe_month_x__18 -0.014136   0.014312  -0.987706 3.2330e-01    
    fe_month_x__19  0.010086   0.015035   0.670832 5.0233e-01    
    fe_month_x__20 -0.029517   0.014799  -1.994517 4.6098e-02 *  
    fe_month_x__21  0.007362   0.015300   0.481210 6.3037e-01    
    fe_month_x__22 -0.001251   0.014875  -0.084070 9.3300e-01    
    fe_month_x__25 -0.073087   0.014602  -5.005171 5.5913e-07 ***
    fe_month_x__26 -0.045122   0.016288  -2.770176 5.6037e-03 ** 
    fe_month_x__27 -0.043437   0.014846  -2.925845 3.4360e-03 ** 
    fe_month_x__28 -0.066506   0.016716  -3.978728 6.9337e-05 ***
    fe_month_x__29 -0.080823   0.014321  -5.643729 1.6688e-08 ***
    fe_month_x__30 -0.037568   0.016009  -2.346694 1.8943e-02 *  
    fe_month_x__31 -0.042259   0.014574  -2.899719 3.7358e-03 ** 
    fe_month_x__32 -0.060653   0.016142  -3.757388 1.7180e-04 ***
    fe_month_x__33 -0.057733   0.014361  -4.020275 5.8175e-05 ***
    fe_month_x__34 -0.093707   0.015933  -5.881162 4.0876e-09 ***
    fe_month_x__35 -0.047777   0.014387  -3.320735 8.9815e-04 ***
    fe_month_x__36 -0.055612   0.016435  -3.383750 7.1532e-04 ***
    fe_month_x__37 -0.050375   0.014403  -3.497573 4.6973e-04 ***
    fe_month_x__38 -0.031039   0.016180  -1.918412 5.5062e-02 .  
    fe_month_x__39 -0.031326   0.014319  -2.187783 2.8688e-02 *  
    fe_month_x__40 -0.030643   0.016128  -1.899954 5.7442e-02 .  
    fe_month_x__41 -0.018822   0.014523  -1.296004 1.9498e-01    
    fe_month_x__42 -0.024786   0.016097  -1.539731 1.2363e-01    
    fe_month_x__43 -0.009421   0.014516  -0.649026 5.1632e-01    
    fe_month_x__44 -0.027601   0.016366  -1.686429 9.1716e-02 .  
    fe_month_x__45 -0.003409   0.014410  -0.236584 8.1298e-01    
    fe_month_x__46 -0.004161   0.016108  -0.258306 7.9617e-01    
    ... 5 variables were removed because of collinearity (fe_year_x_d_36, fe_month_x__23 and 3 others [full set in $collin.var])
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    RMSE: 0.463479   Adj. R2: 0.026058



```R
# save predictions based on ff model
df_results <- cbind(df,predict_ff =predict(fit), residuals_ff = summary(fit)$residuals)
```

### Estimate First Stage with Time Fixed Effects + Judge Random Effects


```R
rf_formula <- as.formula(paste0('bail_met ~', paste(x_timeplace, collapse = " + "),'+(1|judgeid)'))
re_fit = lmer(
  rf_formula,
  data = df
)
summary(re_fit)
```

    fixed-effect model matrix is rank deficient so dropping 5 columns / coefficients
    
    
    Correlation matrix not shown by default, as p = 80 > 12.
    Use print(obj, correlation=TRUE)  or
        vcov(obj)        if you need it
    
    



    Linear mixed model fit by REML. t-tests use Satterthwaite's method [
    lmerModLmerTest]
    Formula: rf_formula
       Data: df
    
    REML criterion at convergence: 123126.4
    
    Scaled residuals: 
        Min      1Q  Median      3Q     Max 
    -1.3838 -0.7335 -0.5949  1.3218  1.9433 
    
    Random effects:
     Groups   Name        Variance  Std.Dev.
     judgeid  (Intercept) 0.0006218 0.02494 
     Residual             0.2144193 0.46305 
    Number of obs: 94355, groups:  judgeid, 186
    
    Fixed effects:
                     Estimate Std. Error         df t value Pr(>|t|)    
    (Intercept)     5.602e-01  1.586e-02  2.616e+04  35.319  < 2e-16 ***
    fe_year_x_d_1  -2.667e-01  2.057e-02  5.868e+04 -12.969  < 2e-16 ***
    fe_year_x_d_2  -2.093e-01  2.060e-02  6.722e+04 -10.157  < 2e-16 ***
    fe_year_x_d_3  -2.454e-01  2.056e-02  5.901e+04 -11.938  < 2e-16 ***
    fe_year_x_d_4  -2.130e-01  2.056e-02  7.171e+04 -10.356  < 2e-16 ***
    fe_year_x_d_5  -2.202e-01  2.047e-02  6.695e+04 -10.758  < 2e-16 ***
    fe_year_x_d_6  -2.009e-01  2.041e-02  7.356e+04  -9.845  < 2e-16 ***
    fe_year_x_d_7  -2.525e-01  2.077e-02  5.962e+04 -12.154  < 2e-16 ***
    fe_year_x_d_8  -2.151e-01  2.042e-02  6.696e+04 -10.531  < 2e-16 ***
    fe_year_x_d_9  -2.583e-01  2.097e-02  6.845e+04 -12.319  < 2e-16 ***
    fe_year_x_d_10 -1.857e-01  2.055e-02  8.021e+04  -9.038  < 2e-16 ***
    fe_year_x_d_11 -2.460e-01  2.151e-02  6.220e+04 -11.435  < 2e-16 ***
    fe_year_x_d_12 -1.802e-01  2.121e-02  7.302e+04  -8.495  < 2e-16 ***
    fe_year_x_d_13 -2.007e-01  2.090e-02  7.331e+04  -9.602  < 2e-16 ***
    fe_year_x_d_14 -1.220e-01  2.064e-02  8.341e+04  -5.911 3.42e-09 ***
    fe_year_x_d_15 -1.682e-01  2.086e-02  5.400e+04  -8.063 7.59e-16 ***
    fe_year_x_d_16 -1.248e-01  2.093e-02  7.407e+04  -5.959 2.54e-09 ***
    fe_year_x_d_17 -1.915e-01  2.101e-02  8.580e+04  -9.115  < 2e-16 ***
    fe_year_x_d_18 -1.563e-01  2.083e-02  9.422e+04  -7.501 6.41e-14 ***
    fe_year_x_d_19 -3.309e-01  2.104e-02  6.599e+04 -15.729  < 2e-16 ***
    fe_year_x_d_20 -3.571e-01  1.565e-02  4.687e+04 -22.813  < 2e-16 ***
    fe_year_x_d_21 -2.983e-01  2.033e-02  6.667e+04 -14.674  < 2e-16 ***
    fe_year_x_d_22 -2.999e-01  1.486e-02  4.409e+04 -20.187  < 2e-16 ***
    fe_year_x_d_23 -2.511e-01  2.022e-02  7.134e+04 -12.420  < 2e-16 ***
    fe_year_x_d_24 -2.861e-01  1.444e-02  4.737e+04 -19.816  < 2e-16 ***
    fe_year_x_d_25 -2.565e-01  2.042e-02  6.278e+04 -12.560  < 2e-16 ***
    fe_year_x_d_26 -2.669e-01  1.419e-02  3.775e+04 -18.813  < 2e-16 ***
    fe_year_x_d_27 -2.038e-01  2.058e-02  7.234e+04  -9.900  < 2e-16 ***
    fe_year_x_d_28 -2.180e-01  1.430e-02  5.403e+04 -15.250  < 2e-16 ***
    fe_year_x_d_29 -1.778e-01  2.124e-02  6.805e+04  -8.370  < 2e-16 ***
    fe_year_x_d_30 -1.864e-01  1.523e-02  5.062e+04 -12.236  < 2e-16 ***
    fe_year_x_d_31 -1.821e-01  2.045e-02  8.028e+04  -8.905  < 2e-16 ***
    fe_year_x_d_32 -2.247e-01  1.455e-02  6.711e+04 -15.450  < 2e-16 ***
    fe_year_x_d_33 -1.548e-01  2.048e-02  6.547e+04  -7.559 4.12e-14 ***
    fe_year_x_d_34 -1.562e-01  1.476e-02  4.704e+04 -10.582  < 2e-16 ***
    fe_year_x_d_35  4.443e-02  2.066e-02  8.763e+04   2.151 0.031504 *  
    fe_month_x__1  -4.165e-04  1.552e-02  2.649e+04  -0.027 0.978582    
    fe_month_x__2  -8.669e-03  1.504e-02  4.370e+04  -0.577 0.564279    
    fe_month_x__3   1.566e-02  1.536e-02  3.496e+04   1.020 0.307771    
    fe_month_x__4   1.140e-02  1.561e-02  3.867e+04   0.731 0.465047    
    fe_month_x__5   3.798e-02  1.488e-02  3.315e+04   2.552 0.010716 *  
    fe_month_x__6   1.678e-03  1.496e-02  4.226e+04   0.112 0.910708    
    fe_month_x__7   1.279e-02  1.524e-02  2.904e+04   0.839 0.401548    
    fe_month_x__8  -4.759e-02  1.520e-02  3.305e+04  -3.132 0.001740 ** 
    fe_month_x__9   3.465e-03  1.524e-02  3.051e+04   0.227 0.820114    
    fe_month_x__10 -2.125e-02  1.493e-02  4.355e+04  -1.424 0.154499    
    fe_month_x__11 -5.282e-03  1.510e-02  3.458e+04  -0.350 0.726586    
    fe_month_x__12 -3.412e-02  1.531e-02  4.639e+04  -2.229 0.025815 *  
    fe_month_x__13 -7.014e-03  1.512e-02  2.904e+04  -0.464 0.642684    
    fe_month_x__14 -1.474e-02  1.505e-02  3.485e+04  -0.979 0.327366    
    fe_month_x__15 -1.067e-03  1.510e-02  3.553e+04  -0.071 0.943681    
    fe_month_x__16 -2.635e-02  1.500e-02  5.338e+04  -1.756 0.079064 .  
    fe_month_x__17  4.042e-03  1.511e-02  2.907e+04   0.267 0.789125    
    fe_month_x__18 -1.195e-02  1.480e-02  3.413e+04  -0.808 0.419233    
    fe_month_x__19  2.192e-03  1.554e-02  3.209e+04   0.141 0.887852    
    fe_month_x__20 -3.050e-02  1.521e-02  4.761e+04  -2.005 0.044990 *  
    fe_month_x__21  3.135e-03  1.572e-02  4.024e+04   0.199 0.841924    
    fe_month_x__22  3.702e-04  1.530e-02  4.570e+04   0.024 0.980688    
    fe_month_x__25 -7.791e-02  1.518e-02  2.738e+04  -5.133 2.87e-07 ***
    fe_month_x__26 -5.089e-02  1.665e-02  5.442e+04  -3.057 0.002240 ** 
    fe_month_x__27 -4.328e-02  1.534e-02  3.509e+04  -2.822 0.004780 ** 
    fe_month_x__28 -6.978e-02  1.714e-02  4.660e+04  -4.072 4.67e-05 ***
    fe_month_x__29 -8.288e-02  1.478e-02  3.577e+04  -5.609 2.05e-08 ***
    fe_month_x__30 -4.259e-02  1.637e-02  5.294e+04  -2.603 0.009251 ** 
    fe_month_x__31 -4.723e-02  1.506e-02  3.157e+04  -3.136 0.001714 ** 
    fe_month_x__32 -5.970e-02  1.656e-02  4.783e+04  -3.605 0.000312 ***
    fe_month_x__33 -6.283e-02  1.483e-02  3.298e+04  -4.236 2.28e-05 ***
    fe_month_x__34 -9.857e-02  1.628e-02  5.845e+04  -6.055 1.42e-09 ***
    fe_month_x__35 -5.845e-02  1.486e-02  3.612e+04  -3.934 8.36e-05 ***
    fe_month_x__36 -5.582e-02  1.679e-02  5.747e+04  -3.325 0.000884 ***
    fe_month_x__37 -5.897e-02  1.488e-02  3.353e+04  -3.963 7.42e-05 ***
    fe_month_x__38 -3.174e-02  1.657e-02  4.949e+04  -1.916 0.055370 .  
    fe_month_x__39 -3.575e-02  1.479e-02  3.774e+04  -2.418 0.015631 *  
    fe_month_x__40 -3.245e-02  1.643e-02  6.401e+04  -1.975 0.048278 *  
    fe_month_x__41 -2.258e-02  1.501e-02  3.271e+04  -1.505 0.132401    
    fe_month_x__42 -2.156e-02  1.649e-02  4.884e+04  -1.307 0.191060    
    fe_month_x__43 -1.848e-02  1.501e-02  3.342e+04  -1.231 0.218192    
    fe_month_x__44 -2.933e-02  1.673e-02  5.640e+04  -1.753 0.079539 .  
    fe_month_x__45 -7.736e-03  1.482e-02  3.850e+04  -0.522 0.601586    
    fe_month_x__46 -5.960e-03  1.642e-02  6.003e+04  -0.363 0.716604    
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    fit warnings:
    fixed-effect model matrix is rank deficient so dropping 5 columns / coefficients



```R
# get residuals & predictions
df_results <- cbind(df_results,predict_judge = predict(re_fit), residuals_judge= predict(re_fit)-df$bail_met, true= df$bail_met)
```

### Get Bounds for different bins according to R2 in first stage


```R
# estimate for different bin sizes - always keep the data for 'best performing bin' per size
df_bins <- data.frame()
for (i in seq(1500,10000,500)){
    out <- estimate_bounds(df_results, treatment_var='bail_met', outcome_var='any_guilty', controls=x_timeplace, bin_size=i)
    out <- out %>% mutate(diff = abs(lb_adjusted-ub_adjusted)) %>% filter(diff==min(diff))
    #print(out)
    df_bins <- rbind(df_bins,out)
    
}
```

    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.


    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"


    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.


    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"


    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.


    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"


    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.


    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"


    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.


    [1] "neg.  or invalid R2"
    [1] "neg.  or invalid R2"


    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.


    [1] "neg.  or invalid R2"


    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.


    [1] "neg.  or invalid R2"


    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.


    [1] "neg.  or invalid R2"


    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.



```R
df_bins
```


<table class="dataframe">
<caption>A data.frame: 18 × 13</caption>
<thead>
	<tr><th scope=col>effect_adjusted</th><th scope=col>lb_adjusted</th><th scope=col>ub_adjusted</th><th scope=col>effect_observed</th><th scope=col>lb_observed</th><th scope=col>ub_observed</th><th scope=col>se_observed</th><th scope=col>df_observed</th><th scope=col>confounder_exposure_r2</th><th scope=col>confounder_outcome_r2</th><th scope=col>group</th><th scope=col>size</th><th scope=col>diff</th></tr>
	<tr><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td> 8.881784e-16</td><td>-0.4566619</td><td>0.4566619</td><td>-0.3423730</td><td>-0.3910503</td><td>-0.2936957</td><td>0.024816258</td><td> 1538</td><td>0.9886466</td><td>0.001421205</td><td>(0.525,0.552]</td><td> 1547</td><td>0.9133238</td></tr>
	<tr><td> 1.054712e-15</td><td>-0.4188892</td><td>0.4188892</td><td>-0.4762920</td><td>-0.5200341</td><td>-0.4325500</td><td>0.022302259</td><td> 1741</td><td>0.9891208</td><td>0.002881356</td><td>(0.254,0.259]</td><td> 1749</td><td>0.8377783</td></tr>
	<tr><td> 1.110223e-16</td><td>-0.2456257</td><td>0.2456257</td><td>-0.2479424</td><td>-0.2903375</td><td>-0.2055473</td><td>0.021619147</td><td> 2291</td><td>0.9702485</td><td>0.001760458</td><td>(0.538,0.595]</td><td> 2303</td><td>0.4912513</td></tr>
	<tr><td> 2.775558e-16</td><td>-0.2604136</td><td>0.2604136</td><td>-0.2472426</td><td>-0.2846200</td><td>-0.2098653</td><td>0.019062550</td><td> 2930</td><td>0.9794168</td><td>0.001206600</td><td>(0.525,0.595]</td><td> 2946</td><td>0.5208271</td></tr>
	<tr><td>-3.330669e-16</td><td>-0.1882398</td><td>0.1882398</td><td>-0.2750860</td><td>-0.3089109</td><td>-0.2412612</td><td>0.017251883</td><td> 3465</td><td>0.9677809</td><td>0.002442850</td><td>(0.515,0.595]</td><td> 3484</td><td>0.3764795</td></tr>
	<tr><td>-3.330669e-16</td><td>-0.1741743</td><td>0.1741743</td><td>-0.2864673</td><td>-0.3181314</td><td>-0.2548031</td><td>0.016150415</td><td> 3871</td><td>0.9670334</td><td>0.002770718</td><td>(0.501,0.595]</td><td> 3892</td><td>0.3483486</td></tr>
	<tr><td>-2.220446e-16</td><td>-0.1555113</td><td>0.1555113</td><td>-0.3153563</td><td>-0.3448725</td><td>-0.2858402</td><td>0.015055347</td><td> 4348</td><td>0.9641028</td><td>0.003757241</td><td>(0.463,0.595]</td><td> 4372</td><td>0.3110227</td></tr>
	<tr><td>-2.775558e-16</td><td>-0.1412986</td><td>0.1412986</td><td>-0.3071577</td><td>-0.3348508</td><td>-0.2794646</td><td>0.014125918</td><td> 4922</td><td>0.9617270</td><td>0.003822857</td><td>(0.442,0.595]</td><td> 4949</td><td>0.2825973</td></tr>
	<tr><td> 2.775558e-16</td><td>-0.1354299</td><td>0.1354299</td><td>-0.2982778</td><td>-0.3248702</td><td>-0.2716854</td><td>0.013564738</td><td> 5340</td><td>0.9615767</td><td>0.003618161</td><td>(0.437,0.595]</td><td> 5369</td><td>0.2708597</td></tr>
	<tr><td> 1.110223e-16</td><td>-0.1306359</td><td>0.1306359</td><td>-0.2742950</td><td>-0.2997725</td><td>-0.2488175</td><td>0.012996279</td><td> 5858</td><td>0.9620721</td><td>0.002997779</td><td>(0.434,0.595]</td><td> 5888</td><td>0.2612718</td></tr>
	<tr><td>-5.551115e-17</td><td>-0.1293316</td><td>0.1293316</td><td>-0.2687256</td><td>-0.2938496</td><td>-0.2436017</td><td>0.012816000</td><td> 6031</td><td>0.9623644</td><td>0.002850905</td><td>(0.432,0.595]</td><td> 6062</td><td>0.2586631</td></tr>
	<tr><td>-8.326673e-17</td><td>-0.1243554</td><td>0.1243554</td><td>-0.2399834</td><td>-0.2629306</td><td>-0.2170361</td><td>0.011706018</td><td> 7213</td><td>0.9660140</td><td>0.002049956</td><td>(0.422,0.595]</td><td> 7247</td><td>0.2487108</td></tr>
	<tr><td>-8.326673e-17</td><td>-0.1243554</td><td>0.1243554</td><td>-0.2399834</td><td>-0.2629306</td><td>-0.2170361</td><td>0.011706018</td><td> 7213</td><td>0.9660140</td><td>0.002049956</td><td>(0.422,0.595]</td><td> 7247</td><td>0.2487108</td></tr>
	<tr><td>-1.110223e-16</td><td>-0.1243500</td><td>0.1243500</td><td>-0.2289380</td><td>-0.2511539</td><td>-0.2067221</td><td>0.011333079</td><td> 7713</td><td>0.9681334</td><td>0.001741477</td><td>(0.417,0.595]</td><td> 7748</td><td>0.2487000</td></tr>
	<tr><td> 1.665335e-16</td><td>-0.1218606</td><td>0.1218606</td><td>-0.2218257</td><td>-0.2431784</td><td>-0.2004730</td><td>0.010892854</td><td> 8359</td><td>0.9693417</td><td>0.001569126</td><td>(0.412,0.595]</td><td> 8395</td><td>0.2437212</td></tr>
	<tr><td>-5.551115e-17</td><td>-0.1133377</td><td>0.1133377</td><td>-0.2204248</td><td>-0.2405853</td><td>-0.2002644</td><td>0.010284798</td><td> 9366</td><td>0.9684062</td><td>0.001600000</td><td>(0.406,0.595]</td><td> 9407</td><td>0.2266754</td></tr>
	<tr><td>-5.551115e-17</td><td>-0.1133377</td><td>0.1133377</td><td>-0.2204248</td><td>-0.2405853</td><td>-0.2002644</td><td>0.010284798</td><td> 9366</td><td>0.9684062</td><td>0.001600000</td><td>(0.406,0.595]</td><td> 9407</td><td>0.2266754</td></tr>
	<tr><td>-8.326673e-17</td><td>-0.1102441</td><td>0.1102441</td><td>-0.2232619</td><td>-0.2424524</td><td>-0.2040715</td><td>0.009790071</td><td>10288</td><td>0.9697437</td><td>0.001577197</td><td>(0.403,0.595]</td><td>10331</td><td>0.2204882</td></tr>
</tbody>
</table>




```R
# plot results
df_bins %>% ggplot(aes(x=size,y= lb_adjusted)) + geom_line() + geom_line(aes(x=size,y=ub_adjusted)) +labs(y='adjusted bounds of bin with smallest interval',x='bin size')
```


    
![png](output_16_0.png)
    


### Make groups based on covariates


```R
# calculate ratio of squared residuals
df_results <- df_results %>% mutate(e_ratio = residuals_ff^2/residuals_judge^2)
```


```R
# define train and test set
set.seed(1234)
ind <- sample(2, nrow(df_results), replace = T, prob = c(0.8, 0.2))
train <- df_results[ind == 1,]
test <- df_results[ind == 2,]
```


```R
# get other potential control variables?
controls <-grep("^n_", names(df), value = TRUE)
```


```R
#Tree Classification
tree_formula <- as.formula(paste0('e_ratio~',paste(x_timeplace, collapse = " + "),'+',paste(controls, collapse = " + ")))
print(tree_formula)
tree <- rpart(tree_formula, data = train, minbucket=1000)
rpart.plot(tree)
```

    e_ratio ~ fe_year_x_d_1 + fe_year_x_d_2 + fe_year_x_d_3 + fe_year_x_d_4 + 
        fe_year_x_d_5 + fe_year_x_d_6 + fe_year_x_d_7 + fe_year_x_d_8 + 
        fe_year_x_d_9 + fe_year_x_d_10 + fe_year_x_d_11 + fe_year_x_d_12 + 
        fe_year_x_d_13 + fe_year_x_d_14 + fe_year_x_d_15 + fe_year_x_d_16 + 
        fe_year_x_d_17 + fe_year_x_d_18 + fe_year_x_d_19 + fe_year_x_d_20 + 
        fe_year_x_d_21 + fe_year_x_d_22 + fe_year_x_d_23 + fe_year_x_d_24 + 
        fe_year_x_d_25 + fe_year_x_d_26 + fe_year_x_d_27 + fe_year_x_d_28 + 
        fe_year_x_d_29 + fe_year_x_d_30 + fe_year_x_d_31 + fe_year_x_d_32 + 
        fe_year_x_d_33 + fe_year_x_d_34 + fe_year_x_d_35 + fe_year_x_d_36 + 
        fe_month_x__1 + fe_month_x__2 + fe_month_x__3 + fe_month_x__4 + 
        fe_month_x__5 + fe_month_x__6 + fe_month_x__7 + fe_month_x__8 + 
        fe_month_x__9 + fe_month_x__10 + fe_month_x__11 + fe_month_x__12 + 
        fe_month_x__13 + fe_month_x__14 + fe_month_x__15 + fe_month_x__16 + 
        fe_month_x__17 + fe_month_x__18 + fe_month_x__19 + fe_month_x__20 + 
        fe_month_x__21 + fe_month_x__22 + fe_month_x__23 + fe_month_x__24 + 
        fe_month_x__25 + fe_month_x__26 + fe_month_x__27 + fe_month_x__28 + 
        fe_month_x__29 + fe_month_x__30 + fe_month_x__31 + fe_month_x__32 + 
        fe_month_x__33 + fe_month_x__34 + fe_month_x__35 + fe_month_x__36 + 
        fe_month_x__37 + fe_month_x__38 + fe_month_x__39 + fe_month_x__40 + 
        fe_month_x__41 + fe_month_x__42 + fe_month_x__43 + fe_month_x__44 + 
        fe_month_x__45 + fe_month_x__46 + fe_month_x__47 + fe_month_x__48 + 
        n_counts + n_acrime_f1 + n_acrime_f2 + n_acrime_f3 + n_acrime_m1 + 
        n_acrime_m2 + n_dcrime_f1 + n_dcrime_f2 + n_dcrime_f3 + n_dcrime_m1 + 
        n_dcrime_m2 + n_crime_other + n_assault + n_burglary + n_drug + 
        n_attmurder + n_arson + n_weapon + n_fraud + n_dui + n_mischief + 
        n_murder + n_theft + n_kidnap + n_trespass + n_rape + n_robbery + 
        n_guilty + n_conv + n_dismiss + n_noaction + n_nolle + n_notguilty + 
        n_withdraw + n_timeserv + n_adjwh + n_transfer + n_property + 
        n_violent + n_guilty_dcrime_m2 + n_guilty_dcrime_m1 + n_guilty_dcrime_f3 + 
        n_guilty_dcrime_f2 + n_guilty_dcrime_f1 + n_cases + n_cases_year



    
![png](output_21_1.png)
    



```R
# get grouping from tree
df_tree <- df_results
df_tree <- df_tree %>% mutate(id = rownames(df_results))
df_tree <- df_tree %>% left_join(as.data.frame(tree$where) %>% mutate(id = rownames(as.data.frame(tree$where))), 
                                       by='id')
df_tree <- df_tree %>% left_join(tree$frame %>% mutate(id = seq(1:nrow(tree$frame))), by=c('tree$where'='id'))
```


```R
df_groups <- estimate_bounds(df_tree, treatment_var='bail_met', outcome_var='any_guilty', controls=x_timeplace,grouping=df_tree$`tree$where`)
```

    Error encountered-regression singular
    



```R
df_groups
```


<table class="dataframe">
<caption>A data.frame: 6 × 12</caption>
<thead>
	<tr><th scope=col>effect_adjusted</th><th scope=col>lb_adjusted</th><th scope=col>ub_adjusted</th><th scope=col>effect_observed</th><th scope=col>lb_observed</th><th scope=col>ub_observed</th><th scope=col>se_observed</th><th scope=col>df_observed</th><th scope=col>confounder_exposure_r2</th><th scope=col>confounder_outcome_r2</th><th scope=col>group</th><th scope=col>size</th></tr>
	<tr><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><td>-1.942890e-16</td><td>-0.11165996</td><td>0.11165996</td><td>-0.2262604</td><td>-0.2462194</td><td>-0.2063015</td><td>0.010182009</td><td> 9436</td><td>0.9681011</td><td>0.0017243196</td><td> 2</td><td> 9517</td></tr>
	<tr><td>-5.551115e-17</td><td>-0.23172811</td><td>0.23172811</td><td>-0.1778229</td><td>-0.2165232</td><td>-0.1391226</td><td>0.019735708</td><td> 2465</td><td>0.9721236</td><td>0.0009444262</td><td> 5</td><td> 2537</td></tr>
	<tr><td>-1.387779e-16</td><td>-0.04967566</td><td>0.04967566</td><td>-0.2377451</td><td>-0.2463243</td><td>-0.2291658</td><td>0.004377157</td><td>52370</td><td>0.9702237</td><td>0.0017288376</td><td> 7</td><td>52451</td></tr>
	<tr><td>-8.326673e-17</td><td>-0.15950401</td><td>0.15950401</td><td>-0.2354245</td><td>-0.2590864</td><td>-0.2117627</td><td>0.012070509</td><td> 7004</td><td>0.9780171</td><td>0.0012208025</td><td> 9</td><td> 7085</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.21866204</td><td>0.21866204</td><td>-0.2470025</td><td>-0.2919730</td><td>-0.2020319</td><td>0.022931387</td><td> 2107</td><td>0.9577857</td><td>0.0024269961</td><td>10</td><td> 2172</td></tr>
	<tr><td> 2.775558e-16</td><td>-0.32710114</td><td>0.32710114</td><td>-0.2398655</td><td>-0.2881731</td><td>-0.1915578</td><td>0.024629781</td><td> 1712</td><td>0.9782036</td><td>0.0012344289</td><td>11</td><td> 1754</td></tr>
</tbody>
</table>



# Ramadan fasting increases leniency in judges from Pakistan and India
Link to paper: https://www.nature.com/articles/s41562-023-01547-3

Link to data:https://www.dropbox.com/scl/fi/gzsjvmf2bt98eclpk6pld/replication_files.rar?rlkey=j647zqvp20higy06nc1d540e0&e=1&dl=0

## Estimate Confounder Bounds based on First Stage R2



```R
# read in data for Pakistan courts
df <- read_dta('replication_files/Input/indian_courts_acq.dta')
head(df)
```


<table class="dataframe">
<caption>A tibble: 6 × 119</caption>
<thead>
	<tr><th scope=col>SDCC</th><th scope=col>Muslim</th><th scope=col>start_date</th><th scope=col>end_date</th><th scope=col>state_code</th><th scope=col>archive</th><th scope=col>court_name</th><th scope=col>date_of_decision</th><th scope=col>decision_year</th><th scope=col>date_of_filing</th><th scope=col>⋯</th><th scope=col>pet_name</th><th scope=col>res_name</th><th scope=col>defendant_name</th><th scope=col>pet_name_hc</th><th scope=col>res_name_hc</th><th scope=col>pet_adv</th><th scope=col>pet_adv_hc</th><th scope=col>res_adv</th><th scope=col>res_adv_hc</th><th scope=col>judge_id</th></tr>
	<tr><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;date&gt;</th><th scope=col>&lt;date&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;date&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;date&gt;</th><th scope=col>⋯</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>1359312</td><td>0</td><td>2016-05-07</td><td>2017-05-08</td><td>13</td><td>Y</td><td>Chief Judicial Magistrate</td><td>2017-02-11</td><td>2017</td><td>2016-12-11</td><td>⋯</td><td>     NA</td><td>NA</td><td>1</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>12906</td></tr>
	<tr><td> 132329</td><td>0</td><td>2015-10-20</td><td>2017-06-02</td><td>13</td><td>Y</td><td>Chief Judicial Magistrate</td><td>2016-11-12</td><td>2016</td><td>2000-11-21</td><td>⋯</td><td>1981301</td><td>NA</td><td>1</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>17054</td></tr>
	<tr><td>1359312</td><td>0</td><td>2016-05-07</td><td>2017-05-08</td><td>13</td><td>Y</td><td>Chief Judicial Magistrate</td><td>2017-02-11</td><td>2017</td><td>2016-12-11</td><td>⋯</td><td>     NA</td><td>NA</td><td>1</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>12906</td></tr>
	<tr><td>1359312</td><td>0</td><td>2016-05-07</td><td>2017-05-08</td><td>13</td><td>Y</td><td>Chief Judicial Magistrate</td><td>2017-02-11</td><td>2017</td><td>2016-12-11</td><td>⋯</td><td>     NA</td><td>NA</td><td>1</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>12906</td></tr>
	<tr><td> 132325</td><td>0</td><td>2015-04-16</td><td>2017-08-17</td><td>13</td><td>Y</td><td>Chief Judicial Magistrate</td><td>2017-07-08</td><td>2017</td><td>2002-11-28</td><td>⋯</td><td> 723956</td><td>NA</td><td>1</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td> 9014</td></tr>
	<tr><td>1359312</td><td>0</td><td>2016-05-07</td><td>2017-05-08</td><td>13</td><td>Y</td><td>Chief Judicial Magistrate</td><td>2017-02-11</td><td>2017</td><td>2016-12-11</td><td>⋯</td><td>     NA</td><td>NA</td><td>1</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>NA</td><td>12906</td></tr>
</tbody>
</table>




```R
# remove NA from strict acquittal
df <-  df %>% drop_na(strict_acquittal)
dim(df)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>372089</li><li>119</li></ol>




```R
# specify covariates as from the original paper
controls <- c('Judgments', 'Criminal_Miscelleneous', 'Session_Judge', 'Rape', 'Assault', 'Robbery', 'Children_Sexual_Assault', 'Kidnapping', 'Fraud', 'Theft')
other_covars <- c('RamadanXHours', 'Daylight_Hours', 'Ramadan')
ff <- c('district_id', 'decision_year', 'decision_month', 'decision_week', 'decision_day')
```

### Estimate first stage with only time fixed effects


```R
# fit model only with non-judge related fixed effects
reg_formula_ff <- as.formula(paste0('Acquittal~1+',paste(controls,collapse='+'),'+',
                                 paste(other_covars, collapse='+'),' + ',
                                            paste(ff, collapse='+')))
reg <- lm(reg_formula_ff, df)
summary(reg)
```


    
    Call:
    lm(formula = reg_formula_ff, data = df)
    
    Residuals:
        Min      1Q  Median      3Q     Max 
    -1.0036 -0.5190  0.3365  0.4470  0.9888 
    
    Coefficients:
                              Estimate Std. Error t value Pr(>|t|)    
    (Intercept)             -1.718e+01  8.558e-01 -20.072  < 2e-16 ***
    Judgments                7.050e-02  5.394e-03  13.070  < 2e-16 ***
    Criminal_Miscelleneous  -3.407e-01  4.073e-03 -83.648  < 2e-16 ***
    Session_Judge            2.227e-02  2.401e-03   9.274  < 2e-16 ***
    Rape                     1.153e-01  1.444e-02   7.989 1.37e-15 ***
    Assault                  3.312e-01  1.040e-01   3.185 0.001449 ** 
    Robbery                  2.868e-02  1.037e-02   2.766 0.005669 ** 
    Children_Sexual_Assault  2.165e-02  1.886e-02   1.148 0.251042    
    Kidnapping               1.764e-01  1.628e-02  10.837  < 2e-16 ***
    Fraud                    2.353e-01  8.905e-02   2.642 0.008243 ** 
    Theft                    1.413e-01  4.156e-02   3.400 0.000674 ***
    RamadanXHours           -1.924e-01  9.797e-03 -19.642  < 2e-16 ***
    Daylight_Hours           3.227e-03  8.206e-04   3.933 8.40e-05 ***
    Ramadan                  2.599e+00  1.328e-01  19.562  < 2e-16 ***
    district_id              3.735e-04  6.110e-06  61.132  < 2e-16 ***
    decision_year            8.677e-03  4.241e-04  20.458  < 2e-16 ***
    decision_month           1.113e-01  1.175e-02   9.467  < 2e-16 ***
    decision_week           -2.708e-02  2.705e-03 -10.008  < 2e-16 ***
    decision_day             7.297e-03  4.009e-04  18.201  < 2e-16 ***
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 0.4877 on 372070 degrees of freedom
    Multiple R-squared:  0.04372,	Adjusted R-squared:  0.04367 
    F-statistic: 944.9 on 18 and 372070 DF,  p-value: < 2.2e-16




```R
# save predictions based on ff model
df_results <- cbind(df,predict_ff =predict(reg), residuals_ff = summary(reg)$residuals)
```

### Estimate First Stage with Time Fixed Effects + Judge Random Effects


```R
# fit model including judge random effects
reg_formula_judge <- as.formula(paste0('Acquittal~1+',paste(controls,collapse='+'),'+',
                                 paste(other_covars, collapse='+'),' + ',
                                            paste(ff, collapse='+'), ' +(1|judge_id)'))
reg_judge <- lmer(reg_formula_judge, df)
summary(reg_judge)
```

    
    Correlation matrix not shown by default, as p = 19 > 12.
    Use print(obj, correlation=TRUE)  or
        vcov(obj)        if you need it
    
    



    Linear mixed model fit by REML. t-tests use Satterthwaite's method [
    lmerModLmerTest]
    Formula: reg_formula_judge
       Data: df
    
    REML criterion at convergence: 332445.6
    
    Scaled residuals: 
        Min      1Q  Median      3Q     Max 
    -2.8762 -0.4285  0.0647  0.6200  3.1644 
    
    Random effects:
     Groups   Name        Variance Std.Dev.
     judge_id (Intercept) 0.09032  0.3005  
     Residual             0.13740  0.3707  
    Number of obs: 372089, groups:  judge_id, 7668
    
    Fixed effects:
                              Estimate Std. Error         df t value Pr(>|t|)    
    (Intercept)             -6.928e+00  1.538e+00  1.804e+05  -4.503 6.69e-06 ***
    Judgments               -2.754e-03  5.367e-03  3.257e+05  -0.513  0.60784    
    Criminal_Miscelleneous  -7.084e-02  5.749e-03  1.884e+05 -12.323  < 2e-16 ***
    Session_Judge            1.704e-02  8.979e-03  7.479e+03   1.898  0.05771 .  
    Rape                     2.606e-02  1.176e-02  3.720e+05   2.215  0.02673 *  
    Assault                  1.062e-01  7.951e-02  3.652e+05   1.335  0.18174    
    Robbery                  2.170e-02  8.348e-03  3.665e+05   2.600  0.00933 ** 
    Children_Sexual_Assault  2.089e-02  1.888e-02  3.679e+05   1.106  0.26862    
    Kidnapping               1.012e-01  1.276e-02  3.696e+05   7.935 2.12e-15 ***
    Fraud                   -4.873e-02  7.334e-02  3.302e+05  -0.665  0.50637    
    Theft                    7.587e-02  3.430e-02  3.462e+05   2.212  0.02699 *  
    RamadanXHours            2.098e-03  7.935e-03  3.720e+05   0.264  0.79145    
    Daylight_Hours           5.564e-03  6.798e-04  3.702e+05   8.184 2.75e-16 ***
    Ramadan                 -4.382e-02  1.076e-01  3.720e+05  -0.407  0.68378    
    district_id              2.941e-04  1.554e-05  1.116e+05  18.921  < 2e-16 ***
    decision_year            3.668e-03  7.626e-04  1.801e+05   4.810 1.51e-06 ***
    decision_month           6.358e-02  9.362e-03  3.688e+05   6.791 1.12e-11 ***
    decision_week           -1.527e-02  2.155e-03  3.688e+05  -7.085 1.39e-12 ***
    decision_day             2.883e-03  3.186e-04  3.689e+05   9.051  < 2e-16 ***
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1



```R
# get residuals & predictions
df_results <- cbind(df_results,predict_judge = predict(reg_judge), residuals_judge= predict(reg_judge)-df$Acquittal, true= df$Acquittal)
```

### Get Bounds for different bins according to R2 in first stage


```R
# estimate for different bin sizes - always keep the data for 'best performing bin' per size
df_bins <- data.frame()
for (i in c(seq(5000,10000,500),seq(10000,300000,10000))){
    out <- estimate_bounds(df_results, treatment_var='Acquittal', outcome_var='recidivism',controls=c(controls,other_covars,ff), bin_size=i)
    out <- out %>% mutate(diff = abs(lb_adjusted-ub_adjusted)) %>% filter(diff==min(diff))
    #print(out)
    df_bins <- rbind(df_bins,out)
    
}
```

    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.
    [1m[22m`summarise()` has grouped output by 'grouping', 'threshold_lower'. You can
    override using the `.groups` argument.



```R
df_bins
```


<table class="dataframe">
<caption>A data.frame: 41 × 13</caption>
<thead>
	<tr><th scope=col>effect_adjusted</th><th scope=col>lb_adjusted</th><th scope=col>ub_adjusted</th><th scope=col>effect_observed</th><th scope=col>lb_observed</th><th scope=col>ub_observed</th><th scope=col>se_observed</th><th scope=col>df_observed</th><th scope=col>confounder_exposure_r2</th><th scope=col>confounder_outcome_r2</th><th scope=col>group</th><th scope=col>size</th><th scope=col>diff</th></tr>
	<tr><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td> 0.000000e+00</td><td>-0.032162694</td><td>0.032162694</td><td>-0.2268586</td><td>-0.2521926</td><td>-0.2015247</td><td>0.012923373</td><td>  6715</td><td>0.4189599</td><td>0.06364240</td><td>(0.488,0.491]  </td><td>  6819</td><td>0.064325387</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.030888264</td><td>0.030888264</td><td>-0.2062939</td><td>-0.2325442</td><td>-0.1800436</td><td>0.013390312</td><td>  5496</td><td>0.3385726</td><td>0.08436742</td><td>(0.412,0.425]  </td><td>  5560</td><td>0.061776527</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.028845761</td><td>0.028845761</td><td>-0.2479194</td><td>-0.2706582</td><td>-0.2251806</td><td>0.011599537</td><td>  6694</td><td>0.4338529</td><td>0.08905141</td><td>(0.448,0.456]  </td><td>  6805</td><td>0.057691522</td></tr>
	<tr><td> 2.775558e-17</td><td>-0.028977588</td><td>0.028977588</td><td>-0.2326602</td><td>-0.2569208</td><td>-0.2083996</td><td>0.012375761</td><td>  6427</td><td>0.3657933</td><td>0.09534267</td><td>(0.402,0.422]  </td><td>  6503</td><td>0.057955175</td></tr>
	<tr><td>-2.775558e-17</td><td>-0.027864162</td><td>0.027864162</td><td>-0.2127007</td><td>-0.2360298</td><td>-0.1893716</td><td>0.011900753</td><td>  6955</td><td>0.3569344</td><td>0.08274823</td><td>(0.409,0.427]  </td><td>  7036</td><td>0.055728325</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.027069749</td><td>0.027069749</td><td>-0.1871375</td><td>-0.2104513</td><td>-0.1638237</td><td>0.011893188</td><td>  7949</td><td>0.3096677</td><td>0.06943442</td><td>(0.414,0.428]  </td><td>  8026</td><td>0.054139497</td></tr>
	<tr><td> 2.775558e-17</td><td>-0.027004476</td><td>0.027004476</td><td>-0.1908894</td><td>-0.2141009</td><td>-0.1676778</td><td>0.011841039</td><td>  7963</td><td>0.3138207</td><td>0.07136138</td><td>(0.419,0.431]  </td><td>  8041</td><td>0.054008951</td></tr>
	<tr><td>-2.775558e-17</td><td>-0.025288211</td><td>0.025288211</td><td>-0.2235693</td><td>-0.2445659</td><td>-0.2025727</td><td>0.010711197</td><td>  8412</td><td>0.3710586</td><td>0.08778428</td><td>(0.382,0.421]  </td><td>  8533</td><td>0.050576422</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.023992389</td><td>0.023992389</td><td>-0.2345355</td><td>-0.2546954</td><td>-0.2143757</td><td>0.010284477</td><td>  9184</td><td>0.3638071</td><td>0.09902358</td><td>(0.394,0.425]  </td><td>  9299</td><td>0.047984778</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.023976738</td><td>0.023976738</td><td>-0.2183175</td><td>-0.2381976</td><td>-0.1984373</td><td>0.010141824</td><td>  9381</td><td>0.3702203</td><td>0.08402802</td><td>(0.4,0.428]    </td><td>  9491</td><td>0.047953476</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.023738952</td><td>0.023738952</td><td>-0.2186612</td><td>-0.2367472</td><td>-0.2005751</td><td>0.009226783</td><td> 11663</td><td>0.4532247</td><td>0.05809352</td><td>(0.484,0.491]  </td><td> 11853</td><td>0.047477904</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.023738952</td><td>0.023738952</td><td>-0.2186612</td><td>-0.2367472</td><td>-0.2005751</td><td>0.009226783</td><td> 11663</td><td>0.4532247</td><td>0.05809352</td><td>(0.484,0.491]  </td><td> 11853</td><td>0.047477904</td></tr>
	<tr><td> 2.775558e-17</td><td>-0.017186171</td><td>0.017186171</td><td>-0.2098463</td><td>-0.2237130</td><td>-0.1959796</td><td>0.007074554</td><td> 19325</td><td>0.3944556</td><td>0.06989284</td><td>(0.402,0.443]  </td><td> 19564</td><td>0.034372343</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.014286851</td><td>0.014286851</td><td>-0.2342579</td><td>-0.2450397</td><td>-0.2234761</td><td>0.005500802</td><td> 30460</td><td>0.4688730</td><td>0.06744498</td><td>(0.47,0.492]   </td><td> 31011</td><td>0.028573702</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.012533420</td><td>0.012533420</td><td>-0.2328122</td><td>-0.2421072</td><td>-0.2235171</td><td>0.004742299</td><td> 40506</td><td>0.4847705</td><td>0.06323808</td><td>(0.447,0.486]  </td><td> 41344</td><td>0.025066840</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.011224067</td><td>0.011224067</td><td>-0.2261908</td><td>-0.2344498</td><td>-0.2179319</td><td>0.004213729</td><td> 52131</td><td>0.4897339</td><td>0.05759133</td><td>(0.461,0.501]  </td><td> 53138</td><td>0.022448135</td></tr>
	<tr><td> 5.551115e-17</td><td>-0.010425362</td><td>0.010425362</td><td>-0.2037927</td><td>-0.2120232</td><td>-0.1955622</td><td>0.004199231</td><td> 60543</td><td>0.4114157</td><td>0.05565468</td><td>[0.00522,0.47] </td><td> 62015</td><td>0.020850724</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.009397504</td><td>0.009397504</td><td>-0.2155863</td><td>-0.2229751</td><td>-0.2081975</td><td>0.003769798</td><td> 72909</td><td>0.4200828</td><td>0.06192356</td><td>[0.00522,0.479]</td><td> 74610</td><td>0.018795007</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.009397504</td><td>0.009397504</td><td>-0.2155863</td><td>-0.2229751</td><td>-0.2081975</td><td>0.003769798</td><td> 72909</td><td>0.4200828</td><td>0.06192356</td><td>[0.00522,0.479]</td><td> 74610</td><td>0.018795007</td></tr>
	<tr><td> 2.775558e-17</td><td>-0.008306424</td><td>0.008306424</td><td>-0.2224492</td><td>-0.2289485</td><td>-0.2159500</td><td>0.003315962</td><td> 91021</td><td>0.4282054</td><td>0.06602205</td><td>[0.00522,0.492]</td><td> 93026</td><td>0.016612848</td></tr>
	<tr><td> 2.775558e-17</td><td>-0.008306424</td><td>0.008306424</td><td>-0.2224492</td><td>-0.2289485</td><td>-0.2159500</td><td>0.003315962</td><td> 91021</td><td>0.4282054</td><td>0.06602205</td><td>[0.00522,0.492]</td><td> 93026</td><td>0.016612848</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.007334003</td><td>0.007334003</td><td>-0.2182036</td><td>-0.2237845</td><td>-0.2126228</td><td>0.002847399</td><td>121488</td><td>0.4545317</td><td>0.05800950</td><td>[0.00522,0.511]</td><td>124030</td><td>0.014668005</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.007334003</td><td>0.007334003</td><td>-0.2182036</td><td>-0.2237845</td><td>-0.2126228</td><td>0.002847399</td><td>121488</td><td>0.4545317</td><td>0.05800950</td><td>[0.00522,0.511]</td><td>124030</td><td>0.014668005</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.007334003</td><td>0.007334003</td><td>-0.2182036</td><td>-0.2237845</td><td>-0.2126228</td><td>0.002847399</td><td>121488</td><td>0.4545317</td><td>0.05800950</td><td>[0.00522,0.511]</td><td>124030</td><td>0.014668005</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.007334003</td><td>0.007334003</td><td>-0.2182036</td><td>-0.2237845</td><td>-0.2126228</td><td>0.002847399</td><td>121488</td><td>0.4545317</td><td>0.05800950</td><td>[0.00522,0.511]</td><td>124030</td><td>0.014668005</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.006226820</td><td>0.006226820</td><td>-0.1976286</td><td>-0.2021480</td><td>-0.1931091</td><td>0.002305885</td><td>182376</td><td>0.4948576</td><td>0.04111403</td><td>[0.00522,0.546]</td><td>186157</td><td>0.012453641</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.006226820</td><td>0.006226820</td><td>-0.1976286</td><td>-0.2021480</td><td>-0.1931091</td><td>0.002305885</td><td>182376</td><td>0.4948576</td><td>0.04111403</td><td>[0.00522,0.546]</td><td>186157</td><td>0.012453641</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.006226820</td><td>0.006226820</td><td>-0.1976286</td><td>-0.2021480</td><td>-0.1931091</td><td>0.002305885</td><td>182376</td><td>0.4948576</td><td>0.04111403</td><td>[0.00522,0.546]</td><td>186157</td><td>0.012453641</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.006226820</td><td>0.006226820</td><td>-0.1976286</td><td>-0.2021480</td><td>-0.1931091</td><td>0.002305885</td><td>182376</td><td>0.4948576</td><td>0.04111403</td><td>[0.00522,0.546]</td><td>186157</td><td>0.012453641</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.006226820</td><td>0.006226820</td><td>-0.1976286</td><td>-0.2021480</td><td>-0.1931091</td><td>0.002305885</td><td>182376</td><td>0.4948576</td><td>0.04111403</td><td>[0.00522,0.546]</td><td>186157</td><td>0.012453641</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.006226820</td><td>0.006226820</td><td>-0.1976286</td><td>-0.2021480</td><td>-0.1931091</td><td>0.002305885</td><td>182376</td><td>0.4948576</td><td>0.04111403</td><td>[0.00522,0.546]</td><td>186157</td><td>0.012453641</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.006226820</td><td>0.006226820</td><td>-0.1976286</td><td>-0.2021480</td><td>-0.1931091</td><td>0.002305885</td><td>182376</td><td>0.4948576</td><td>0.04111403</td><td>[0.00522,0.546]</td><td>186157</td><td>0.012453641</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.006226820</td><td>0.006226820</td><td>-0.1976286</td><td>-0.2021480</td><td>-0.1931091</td><td>0.002305885</td><td>182376</td><td>0.4948576</td><td>0.04111403</td><td>[0.00522,0.546]</td><td>186157</td><td>0.012453641</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.006226820</td><td>0.006226820</td><td>-0.1976286</td><td>-0.2021480</td><td>-0.1931091</td><td>0.002305885</td><td>182376</td><td>0.4948576</td><td>0.04111403</td><td>[0.00522,0.546]</td><td>186157</td><td>0.012453641</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.006226820</td><td>0.006226820</td><td>-0.1976286</td><td>-0.2021480</td><td>-0.1931091</td><td>0.002305885</td><td>182376</td><td>0.4948576</td><td>0.04111403</td><td>[0.00522,0.546]</td><td>186157</td><td>0.012453641</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.004712886</td><td>0.004712886</td><td>-0.1705809</td><td>-0.1738027</td><td>-0.1673592</td><td>0.001643776</td><td>362552</td><td>0.5443041</td><td>0.02486789</td><td>[0.00522,1.08] </td><td>372089</td><td>0.009425773</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.004712886</td><td>0.004712886</td><td>-0.1705809</td><td>-0.1738027</td><td>-0.1673592</td><td>0.001643776</td><td>362552</td><td>0.5443041</td><td>0.02486789</td><td>[0.00522,1.08] </td><td>372089</td><td>0.009425773</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.004712886</td><td>0.004712886</td><td>-0.1705809</td><td>-0.1738027</td><td>-0.1673592</td><td>0.001643776</td><td>362552</td><td>0.5443041</td><td>0.02486789</td><td>[0.00522,1.08] </td><td>372089</td><td>0.009425773</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.004712886</td><td>0.004712886</td><td>-0.1705809</td><td>-0.1738027</td><td>-0.1673592</td><td>0.001643776</td><td>362552</td><td>0.5443041</td><td>0.02486789</td><td>[0.00522,1.08] </td><td>372089</td><td>0.009425773</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.004712886</td><td>0.004712886</td><td>-0.1705809</td><td>-0.1738027</td><td>-0.1673592</td><td>0.001643776</td><td>362552</td><td>0.5443041</td><td>0.02486789</td><td>[0.00522,1.08] </td><td>372089</td><td>0.009425773</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.004712886</td><td>0.004712886</td><td>-0.1705809</td><td>-0.1738027</td><td>-0.1673592</td><td>0.001643776</td><td>362552</td><td>0.5443041</td><td>0.02486789</td><td>[0.00522,1.08] </td><td>372089</td><td>0.009425773</td></tr>
</tbody>
</table>




```R
# plot results
df_bins %>% ggplot(aes(x=size,y= lb_adjusted)) + geom_line() + geom_line(aes(x=size,y=ub_adjusted)) +labs(y='adjusted bounds of bin with smallest interval',x='bin size')
```


    
![png](output_39_0.png)
    


### Make groups based on covariates


```R
# calculate ratio of squared residuals
df_results <- df_results %>% mutate(e_ratio = residuals_ff^2/residuals_judge^2)
```


```R
# define train and test set
set.seed(1234)
ind <- sample(2, nrow(df_results), replace = T, prob = c(0.8, 0.2))
train <- df_results[ind == 1,]
test <- df_results[ind == 2,]
```


```R
tree_formula <- as.formula(paste0('e_ratio~',paste(controls,collapse='+'),' + ',paste(other_covars,collapse='+'),' + ',paste(ff,collapse='+')))

```


```R
#Tree Classification
print(tree_formula)
tree <- rpart(tree_formula, data = train, cp=0.00001, minbucket=1000)
rpart.plot(tree)
```

    e_ratio ~ Judgments + Criminal_Miscelleneous + Session_Judge + 
        Rape + Assault + Robbery + Children_Sexual_Assault + Kidnapping + 
        Fraud + Theft + RamadanXHours + Daylight_Hours + Ramadan + 
        district_id + decision_year + decision_month + decision_week + 
        decision_day



    
![png](output_44_1.png)
    



```R
# get grouping from tree
df_tree <- df_results
df_tree <- df_tree %>% mutate(id = rownames(df_results))
df_tree <- df_tree %>% left_join(as.data.frame(tree$where) %>% mutate(id = rownames(as.data.frame(tree$where))), 
                                       by='id')
df_tree <- df_tree %>% left_join(tree$frame %>% mutate(id = seq(1:nrow(tree$frame))), by=c('tree$where'='id'))
```


```R
df_groups <- estimate_bounds(df_tree, treatment_var='Acquittal', outcome_var='recidivism', controls=c(controls,other_covars,ff),grouping=df_tree$`tree$where`)
```

    Error encountered-regression singular
    



```R
df_groups
```


<table class="dataframe">
<caption>A data.frame: 15 × 12</caption>
<thead>
	<tr><th scope=col>effect_adjusted</th><th scope=col>lb_adjusted</th><th scope=col>ub_adjusted</th><th scope=col>effect_observed</th><th scope=col>lb_observed</th><th scope=col>ub_observed</th><th scope=col>se_observed</th><th scope=col>df_observed</th><th scope=col>confounder_exposure_r2</th><th scope=col>confounder_outcome_r2</th><th scope=col>group</th><th scope=col>size</th></tr>
	<tr><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><td> 2.775558e-17</td><td>-0.00715357</td><td>0.00715357</td><td>-0.17971534</td><td>-0.18473752</td><td>-0.174693156</td><td>0.002562364</td><td>147200</td><td>0.5221902</td><td>0.0305778793</td><td> 5</td><td>150848</td></tr>
	<tr><td>-2.775558e-17</td><td>-0.01283281</td><td>0.01283281</td><td>-0.12839007</td><td>-0.13628785</td><td>-0.120492289</td><td>0.004029477</td><td> 62713</td><td>0.6249120</td><td>0.0097167772</td><td> 9</td><td> 63834</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.01647374</td><td>0.01647374</td><td>-0.17268457</td><td>-0.18357338</td><td>-0.161795755</td><td>0.005555416</td><td> 33120</td><td>0.5726059</td><td>0.0217749018</td><td>11</td><td> 34533</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.09872328</td><td>0.09872328</td><td>-0.20506189</td><td>-0.27705828</td><td>-0.133065500</td><td>0.036686627</td><td>   948</td><td>0.4861434</td><td>0.0348356165</td><td>12</td><td>  1005</td></tr>
	<tr><td>-5.551115e-17</td><td>-0.02977866</td><td>0.02977866</td><td>-0.24184165</td><td>-0.26472860</td><td>-0.218954699</td><td>0.011675519</td><td>  8263</td><td>0.4471564</td><td>0.0641970359</td><td>14</td><td>  8463</td></tr>
	<tr><td> 1.387779e-17</td><td>-0.08448453</td><td>0.08448453</td><td>-0.09899959</td><td>-0.16105872</td><td>-0.036940463</td><td>0.031644625</td><td>  2041</td><td>0.4631547</td><td>0.0055583632</td><td>16</td><td>  2114</td></tr>
	<tr><td> 1.387779e-17</td><td>-0.13759650</td><td>0.13759650</td><td>-0.11658296</td><td>-0.20071850</td><td>-0.032447424</td><td>0.042873905</td><td>   977</td><td>0.6274088</td><td>0.0044943983</td><td>17</td><td>  1012</td></tr>
	<tr><td>-6.938894e-18</td><td>-0.07548405</td><td>0.07548405</td><td>-0.04065785</td><td>-0.08561866</td><td> 0.004302960</td><td>0.022927584</td><td>  2309</td><td>0.6453330</td><td>0.0007484886</td><td>18</td><td>  2689</td></tr>
	<tr><td> 1.387779e-17</td><td>-0.03316508</td><td>0.03316508</td><td>-0.07956103</td><td>-0.09867201</td><td>-0.060450054</td><td>0.009749622</td><td> 11167</td><td>0.6689002</td><td>0.0029517964</td><td>21</td><td> 11526</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.08628756</td><td>0.08628756</td><td>-0.06394624</td><td>-0.13741861</td><td> 0.009526126</td><td>0.037443006</td><td>  1041</td><td>0.2795210</td><td>0.0072217885</td><td>22</td><td>  1091</td></tr>
	<tr><td> 1.387779e-17</td><td>-0.06288389</td><td>0.06288389</td><td>-0.11699870</td><td>-0.15470216</td><td>-0.079295239</td><td>0.019228593</td><td>  2833</td><td>0.6429950</td><td>0.0072558313</td><td>23</td><td>  2903</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.02618926</td><td>0.02618926</td><td>-0.11747305</td><td>-0.13406680</td><td>-0.100879286</td><td>0.008465593</td><td> 13382</td><td>0.6023236</td><td>0.0095003710</td><td>26</td><td> 13610</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.06965905</td><td>0.06965905</td><td>-0.19309479</td><td>-0.24609108</td><td>-0.140098495</td><td>0.027020775</td><td>  1755</td><td>0.4421242</td><td>0.0367165324</td><td>27</td><td>  1780</td></tr>
	<tr><td>-1.387779e-17</td><td>-0.09099016</td><td>0.09099016</td><td>-0.06819459</td><td>-0.12189143</td><td>-0.014497746</td><td>0.027372594</td><td>  1367</td><td>0.6523244</td><td>0.0024199701</td><td>28</td><td>  1422</td></tr>
	<tr><td> 0.000000e+00</td><td>-0.10064684</td><td>0.10064684</td><td> 0.03578858</td><td>-0.02479908</td><td> 0.096376226</td><td>0.030873498</td><td>   956</td><td>0.6375273</td><td>0.0007991636</td><td>29</td><td>  1052</td></tr>
</tbody>
</table>


